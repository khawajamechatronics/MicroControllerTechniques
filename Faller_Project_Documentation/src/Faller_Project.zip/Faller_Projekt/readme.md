Buttons
=======

Menu
----

Keyboard:

  - ENTER / T: Start tetris
  - H: View highscore

Buttons:

  - PB5: Start Tetris
  - PB6: View the scoreboard

Tetris
------

Keyboard:

  - LEFT: left
  - RIGHT: right
  - UP: rotate clockwise
  - DOWN: drop tetromino by one field
  - SPACE: drop tetromino to the floor

Buttons:

  - PB1: drop tetromino to the floor
  - PB2: rotate clockwise
  - PB3: left
  - PB4: right
  - PB5: drop tetromino to the floor
  - PB6: drop tetromino by one field

Highscore
---------

Keyboard:

  - L: Clear highscore
  - E: Exit highscore
  - Y: Yes
  - N: No

Buttons:

  - PB4: Clear highscore
  - PB5: Yes
  - PB6: No / Exit highscore

Highscore - Name Entry
------------------------

Keyboard:

  - BACKSPACE: Delete character
  - ENTER: Finish

Buttons:

  - PB1: Delete character
  - PB2: Add character
  - PB3: Previous character value (Down)
  - PB4: Next character value (Up)
  - PB5: Finish
